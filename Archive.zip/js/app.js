import * as THREE from "three";
import {REVISION} from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js'
import fragment from "./shader/fragment.glsl";
import vertex from "./shader/vertex.glsl";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import {vec4,vec3,Fn,uv,texture,uniform,normalLocal,mul,positionLocal,pass,overlay,refract,positionWorld,cameraPosition,normalize,length,screenUV,normalWorld,vec2,textureBicubic,float,negate,smoothstep,sin,cos,mat4,div,modelWorldMatrix,transformedNormalWorld,cameraProjectionMatrix,cameraViewMatrix,Loop} from 'three/tsl'
import GUI from 'lil-gui'; 
import gsap from "gsap";
import room from "../room.jpg";
import room_depth from "../empty-room.jpg";

export default class Sketch {
  constructor(options) {
    this.scene = new THREE.Scene();

    this.container = options.dom;
    this.width = this.container.offsetWidth;
    this.height = this.container.offsetHeight;
    this.renderer = new THREE.WebGLRenderer();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    this.renderer.setSize(this.width, this.height);
    this.renderer.setClearColor(0xeeeeee, 1); 

    this.container.appendChild(this.renderer.domElement);

    this.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, -1, 1);
    this.time = 0;
    this.mouse = new THREE.Vector2(0.5, 0.5);

    const THREE_PATH = `https://unpkg.com/three@0.${REVISION}.x`
    this.dracoLoader = new DRACOLoader( new THREE.LoadingManager() ).setDecoderPath( `${THREE_PATH}/examples/jsm/libs/draco/gltf/` );
    this.gltfLoader = new GLTFLoader();
    this.gltfLoader.setDRACOLoader(this.dracoLoader);

    this.isPlaying = true;
    
    this.addObjects();
    this.resize();
    this.render();
    this.setupResize();
    this.setupMouseMove();
  }

  setUpSettings() {
    this.settings = {
      progress: 0,
    };
    this.gui = new GUI();
    this.gui.add(this.settings, "progress", 0, 1, 0.01).onChange((val)=>{})
  }

  setupMouseMove() {
    window.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX / this.width;
      this.mouse.y = 1.0 - e.clientY / this.height;
    });
  }

  setupResize() {
    window.addEventListener("resize", this.resize.bind(this));
  }

  resize() {
    this.width = this.container.offsetWidth;
    this.height = this.container.offsetHeight;
    this.renderer.setSize(this.width, this.height);
  }

  addObjects() {
    // Load textures
    const textureLoader = new THREE.TextureLoader();
    const colorTexture = textureLoader.load(room);
    const depthTexture = textureLoader.load(room_depth);

    this.material = new THREE.ShaderMaterial({
      extensions: {
        derivatives: "#extension GL_OES_standard_derivatives : enable"
      },
      side: THREE.DoubleSide,
      uniforms: {
        time: { value: 0 },
        mouse: { value: this.mouse },
        colorTexture: { value: colorTexture },
        depthTexture: { value: depthTexture }
      },
      vertexShader: vertex,
      fragmentShader: fragment
    });

    // Create a fullscreen quad
    this.geometry = new THREE.PlaneGeometry(2, 2);
    this.plane = new THREE.Mesh(this.geometry, this.material);
    this.scene.add(this.plane);
  }

  addLights() {
    const light1 = new THREE.AmbientLight(0xffffff, 0.5);
    this.scene.add(light1);

    const light2 = new THREE.DirectionalLight(0xffffff, 0.5);
    light2.position.set(0.5, 0, 0.866); // ~60º
    this.scene.add(light2);

    this.pmremGenerator = new THREE.PMREMGenerator( this.renderer );
    this.scene.environment = this.pmremGenerator.fromScene( new RoomEnvironment(), 0.04 ).texture;
  }

  stop() {
    this.isPlaying = false;
  }

  play() {
    if(!this.isPlaying){
      this.isPlaying = true;
      this.render()
    }
  }

  render() {
    if (!this.isPlaying) return;
    this.time += 0.05;
    this.material.uniforms.time.value = this.time;
    this.material.uniforms.mouse.value = this.mouse;
    requestAnimationFrame(this.render.bind(this));
    this.renderer.render(this.scene, this.camera);
  }
}

new Sketch({
  dom: document.getElementById("container")
});
