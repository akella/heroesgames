uniform float time;
uniform float progress;
uniform sampler2D texture1;
uniform vec4 resolution;
uniform vec2 mouse;
uniform sampler2D colorTexture;
uniform sampler2D depthTexture;
varying vec2 vUv;
varying vec3 vPosition;
float PI = 3.141592653589793238;
void main()	{
	// vec2 newUV = (vUv - vec2(0.5))*resolution.zw + vec2(0.5);
	
	// Amount of parallax effect
	float strength = 0.05;
	
	// Get the depth value from the depth texture
	float depth = texture2D(depthTexture, vUv).r;
	
	// Calculate offset based on mouse position
	vec2 offset = (mouse - 0.5) * 0.5; // Convert mouse from [0,1] to [-1,1]
	
	// Apply parallax offset based on depth
	vec2 parallaxUV = vUv - offset * depth * strength;
	
	// Sample the color texture with the parallax offset
	vec4 color = texture2D(colorTexture, parallaxUV);
	
	gl_FragColor = color;
}